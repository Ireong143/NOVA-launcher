# NOVA Launcher

NOVA Launcher is an Android home-screen replacement prototype built with Kotlin and Jetpack Compose.

## Included in this first version

- Android HOME launcher intent filter
- Minimal dark NOVA home screen with live clock and date
- Launchable-app discovery through PackageManager
- App drawer with search
- Launch installed apps
- Quick panel (theme shortcut and system-control guidance)
- Settings for dark mode, icon size, and built-in gradient wallpapers
- DataStore-backed preferences

## Important limitations

This is a launcher app, not a replacement Android operating system. A normal third-party launcher cannot replace the system lock screen, notification shade, status bar, or privileged connectivity controls. The quick panel in this prototype is an in-app panel; system controls are subject to Android permissions and device policy.

The app queries activities that declare the standard launcher intent. It does not request the broad `QUERY_ALL_PACKAGES` permission.

## Build an APK

### Option A: GitHub Actions from a phone

1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run the workflow named **Build NOVA Launcher APK**.
4. When it finishes, open the workflow run and download the `nova-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on your Android phone. You may need to allow installation from that browser or file manager.

### Option B: Android Studio

Open this folder as an Android Studio project, sync Gradle, then run the `assembleDebug` task.

## First launch

1. Install and open NOVA Launcher.
2. Press the Android Home button.
3. Choose NOVA Launcher and select **Always** if you want it as the default home app.
4. To change it later, use Android Settings > Apps > Default apps > Home app (wording varies by device).

## Technical baseline

- Kotlin
- Jetpack Compose
- Material 3
- DataStore Preferences
- minSdk 26
- compileSdk 35
- targetSdk 35

This source project has not been compiled in this chat environment. Run the build workflow to verify dependency resolution and compilation before installing.
