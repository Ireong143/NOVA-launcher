package com.nova.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun QuickPanel(
    darkMode: Boolean,
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenWifiSettings: () -> Unit,
    onToggleTheme: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
            .background(Color(0xCC050812))
            .statusBarsPadding()
            .padding(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("제어 센터", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                Text("NOVA QUICK PANEL", color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "닫기", tint = Color.White)
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile("Wi-Fi", "기기 설정 열기", Icons.Default.Wifi, Modifier.weight(1f)) {
                onOpenWifiSettings()
            }
            QuickTile("테마", if (darkMode) "다크 모드" else "라이트 모드", Icons.Default.Settings, Modifier.weight(1f), onToggleTheme)
        }
        Spacer(Modifier.height(12.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f))
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("밝기 및 연결 설정", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Wi-Fi는 Android 기기 설정에서 변경할 수 있습니다. 블루투스, 화면 밝기 및 회전도 Android 시스템 설정의 권한과 정책을 따릅니다.",
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onOpenSettings) {
                    Text("NOVA 설정 열기")
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("일부 시스템 토글은 Android 권한 제한으로 직접 변경할 수 없습니다.", color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun QuickTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.height(112.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.13f)),
        onClick = onClick
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, contentDescription = null, tint = Color.White)
            Column {
                Text(title, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
