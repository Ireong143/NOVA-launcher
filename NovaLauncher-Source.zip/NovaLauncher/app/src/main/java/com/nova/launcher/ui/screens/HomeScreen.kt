package com.nova.launcher.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nova.launcher.domain.model.AppInfo
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    apps: List<AppInfo>,
    iconScale: Float,
    onOpenApps: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenQuickPanel: () -> Unit,
    onLaunchApp: (String) -> Unit
) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d"))
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 22.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("NOVA", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("YOUR SPACE", color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircleAction(Icons.Default.Tune, "빠른 설정", onOpenQuickPanel)
                CircleAction(Icons.Default.Settings, "설정", onOpenSettings)
            }
        }

        Spacer(Modifier.weight(0.8f))

        Column(modifier = Modifier.fillMaxWidth().padding(start = 4.dp)) {
            Text(date.uppercase(), color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelLarge)
            Text(
                time,
                color = Color.White,
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.ExtraLight
            )
            Text("Make today yours.", color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.bodyLarge)
        }

        Spacer(Modifier.height(28.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.12f))
                .clickable(onClick = onOpenApps)
                .padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = Color.White.copy(alpha = 0.8f))
            Spacer(Modifier.width(10.dp))
            Text("앱 검색 및 실행", color = Color.White.copy(alpha = 0.75f))
            Spacer(Modifier.weight(1f))
            Text("⌕", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.titleLarge)
        }

        Spacer(Modifier.height(24.dp))
        Text("FAVORITES", color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(12.dp))

        val favorites = apps.take(4)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.Start)
        ) {
            favorites.forEach { app ->
                Column(
                    modifier = Modifier.weight(1f).clickable { onLaunchApp(app.packageName) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        bitmap = app.icon.asImageBitmap(),
                        contentDescription = app.label,
                        modifier = Modifier.size((48 * iconScale).dp).clip(RoundedCornerShape(15.dp))
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(app.label, color = Color.White, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                }
            }
            if (favorites.isEmpty()) {
                Text("앱을 불러오는 중...", color = Color.White.copy(alpha = 0.7f))
            }
        }

        Spacer(Modifier.weight(0.65f))

        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 66.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = onOpenApps,
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White.copy(alpha = 0.16f),
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.Apps, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("모든 앱")
            }
        }
    }
}

@Composable
private fun CircleAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier.size(42.dp).clip(CircleShape)
            .background(Color.White.copy(alpha = 0.13f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = Color.White)
    }
}
