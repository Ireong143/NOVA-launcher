package com.nova.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import android.content.Intent
import android.provider.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nova.launcher.data.LauncherSettings
import com.nova.launcher.data.SettingsRepository
import com.nova.launcher.platform.AppRepository
import com.nova.launcher.ui.screens.AppDrawer
import com.nova.launcher.ui.screens.HomeScreen
import com.nova.launcher.ui.screens.QuickPanel
import com.nova.launcher.ui.screens.SettingsScreen
import kotlinx.coroutines.launch

private enum class Page { HOME, APPS, SETTINGS }

@Composable
fun NovaApp(settings: LauncherSettings, settingsRepository: SettingsRepository) {
    val context = LocalContext.current
    val appRepository = remember { AppRepository(context) }
    var apps by remember { mutableStateOf(emptyList<com.nova.launcher.domain.model.AppInfo>()) }
    var page by remember { mutableStateOf(Page.HOME) }
    var quickPanelOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        apps = appRepository.loadLaunchableApps()
    }

    val backgrounds = listOf(
        listOf(Color(0xFF11172B), Color(0xFF33285B), Color(0xFF111827)),
        listOf(Color(0xFF071D25), Color(0xFF145B60), Color(0xFF0B1722)),
        listOf(Color(0xFF25152F), Color(0xFF713D65), Color(0xFF171827))
    )
    val gradient = backgrounds[settings.wallpaperIndex.coerceIn(0, 2)]

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(gradient))
    ) {
        when (page) {
            Page.HOME -> HomeScreen(
                apps = apps,
                iconScale = settings.iconScale,
                onOpenApps = { page = Page.APPS },
                onOpenSettings = { page = Page.SETTINGS },
                onOpenQuickPanel = { quickPanelOpen = true },
                onLaunchApp = appRepository::launch
            )
            Page.APPS -> AppDrawer(
                apps = apps,
                iconScale = settings.iconScale,
                onBack = { page = Page.HOME },
                onLaunchApp = appRepository::launch
            )
            Page.SETTINGS -> SettingsScreen(
                settings = settings,
                onBack = { page = Page.HOME },
                onDarkModeChange = { value -> scope.launch { settingsRepository.setDarkMode(value) } },
                onIconScaleChange = { value -> scope.launch { settingsRepository.setIconScale(value) } },
                onWallpaperChange = { value -> scope.launch { settingsRepository.setWallpaperIndex(value) } }
            )
        }

        if (quickPanelOpen) {
            QuickPanel(
                darkMode = settings.darkMode,
                onDismiss = { quickPanelOpen = false },
                onOpenSettings = {
                    quickPanelOpen = false
                    page = Page.SETTINGS
                },
                onOpenWifiSettings = {
                    quickPanelOpen = false
                    runCatching { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
                },
                onToggleTheme = {
                    scope.launch { settingsRepository.setDarkMode(!settings.darkMode) }
                }
            )
        }

        if (page == Page.HOME) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
                    .background(Color.Black.copy(alpha = 0.16f), RoundedCornerShape(50))
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("N O V A", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.75f))
                Text("•", color = Color.White.copy(alpha = 0.5f))
                Text("${apps.size} apps", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.65f))
            }
        }
    }
}
