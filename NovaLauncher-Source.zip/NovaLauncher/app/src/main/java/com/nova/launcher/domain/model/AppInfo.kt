package com.nova.launcher.domain.model

import android.graphics.Bitmap

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Bitmap
)
