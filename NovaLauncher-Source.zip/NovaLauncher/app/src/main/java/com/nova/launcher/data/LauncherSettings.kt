package com.nova.launcher.data

data class LauncherSettings(
    val darkMode: Boolean = true,
    val iconScale: Float = 1.0f,
    val wallpaperIndex: Int = 0
)
