package com.nova.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NovaDark = darkColorScheme(
    primary = Color(0xFFB7A6FF),
    secondary = Color(0xFF8BD8D0),
    background = Color(0xFF080B14),
    surface = Color(0xFF121827),
    surfaceVariant = Color(0xFF20283A),
    onPrimary = Color(0xFF17122A),
    onBackground = Color(0xFFF4F2FF),
    onSurface = Color(0xFFF4F2FF)
)

private val NovaLight = lightColorScheme(
    primary = Color(0xFF5142A5),
    secondary = Color(0xFF176C68),
    background = Color(0xFFF3F4FA),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE7E9F2),
    onBackground = Color(0xFF171827),
    onSurface = Color(0xFF171827)
)

@Composable
fun NovaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) NovaDark else NovaLight,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
