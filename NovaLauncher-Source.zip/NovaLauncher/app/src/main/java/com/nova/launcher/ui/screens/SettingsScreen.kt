package com.nova.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nova.launcher.data.LauncherSettings

@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    onBack: () -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onIconScaleChange: (Float) -> Unit,
    onWallpaperChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(20.dp)
    ) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "뒤로")
            }
            Text("NOVA 설정", style = MaterialTheme.typography.headlineSmall)
        }
        Spacer(Modifier.height(20.dp))
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("화면 테마", style = MaterialTheme.typography.titleMedium)
                Text("다크 모드 사용", style = MaterialTheme.typography.bodyMedium)
                Switch(checked = settings.darkMode, onCheckedChange = onDarkModeChange)
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("아이콘 크기", style = MaterialTheme.typography.titleMedium)
                Text("${(settings.iconScale * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = settings.iconScale,
                    onValueChange = onIconScaleChange,
                    valueRange = 0.75f..1.4f
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("배경 스타일", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(Color(0xFF33285B), Color(0xFF145B60), Color(0xFF713D65)).forEachIndexed { index, color ->
                        androidx.compose.foundation.layout.Box(
                            modifier = Modifier.weight(1f).height(54.dp)
                                .background(color, RoundedCornerShape(14.dp))
                        ) {
                            TextButton(onClick = { onWallpaperChange(index) }) {
                                Text(if (settings.wallpaperIndex == index) "선택됨" else "선택", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("NOVA Launcher 1.0.0", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
    }
}
