package com.nova.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.nova.launcher.data.SettingsRepository
import com.nova.launcher.ui.NovaApp
import com.nova.launcher.ui.theme.NovaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val context = LocalContext.current
            val repository = remember { SettingsRepository(context) }
            val settings by repository.settings.collectAsState(
                initial = com.nova.launcher.data.LauncherSettings()
            )
            NovaTheme(darkTheme = settings.darkMode) {
                NovaApp(settings = settings, settingsRepository = repository)
            }
        }
    }
}
