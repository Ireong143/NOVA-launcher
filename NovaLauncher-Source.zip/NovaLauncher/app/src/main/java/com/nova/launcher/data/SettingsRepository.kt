package com.nova.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.novaDataStore by preferencesDataStore(name = "nova_preferences")

class SettingsRepository(private val context: Context) {
    private object Keys {
        val darkMode = booleanPreferencesKey("dark_mode")
        val iconScale = floatPreferencesKey("icon_scale")
        val wallpaperIndex = intPreferencesKey("wallpaper_index")
    }

    val settings: Flow<LauncherSettings> = context.novaDataStore.data.map { prefs ->
        LauncherSettings(
            darkMode = prefs[Keys.darkMode] ?: true,
            iconScale = prefs[Keys.iconScale] ?: 1.0f,
            wallpaperIndex = prefs[Keys.wallpaperIndex] ?: 0
        )
    }

    suspend fun setDarkMode(value: Boolean) {
        context.novaDataStore.edit { it[Keys.darkMode] = value }
    }

    suspend fun setIconScale(value: Float) {
        context.novaDataStore.edit { it[Keys.iconScale] = value.coerceIn(0.75f, 1.4f) }
    }

    suspend fun setWallpaperIndex(value: Int) {
        context.novaDataStore.edit { it[Keys.wallpaperIndex] = value.coerceIn(0, 2) }
    }
}
